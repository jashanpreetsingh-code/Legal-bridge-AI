# ==============================================================================
# LEGAL-BRIDGE AI: Start Vite + React Frontend on Windows
# ==============================================================================
Write-Host ">>> Starting Legal-Bridge AI Frontend..." -ForegroundColor Cyan

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Split-Path -Parent $ScriptDir
$FrontendDir = Join-Path $ProjectRoot "frontend"

Set-Location $FrontendDir

if (-not (Test-Path (Join-Path $FrontendDir "node_modules"))) {
    Write-Host "Installing frontend dependencies..." -ForegroundColor Yellow
    npm.cmd install
}

Write-Host ">>> Launching Vite Dev Server on http://localhost:5173..." -ForegroundColor Green
npm.cmd run dev
