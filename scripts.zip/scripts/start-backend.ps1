# ==============================================================================
# LEGAL-BRIDGE AI: Start FastAPI Backend on Windows
# ==============================================================================
Write-Host ">>> Starting Legal-Bridge AI Backend..." -ForegroundColor Cyan

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Split-Path -Parent $ScriptDir
$BackendDir = Join-Path $ProjectRoot "backend"
$VenvPython = Join-Path $BackendDir "venv\Scripts\python.exe"

if (-not (Test-Path $VenvPython)) {
    Write-Host "Virtual environment not found at $VenvPython. Creating..." -ForegroundColor Yellow
    python -m venv (Join-Path $BackendDir "venv")
    & $VenvPython -m pip install -r (Join-Path $BackendDir "requirements.txt")
}

Set-Location $BackendDir
Write-Host ">>> Launching Uvicorn on http://127.0.0.1:8000 (API Docs at /docs)..." -ForegroundColor Green
& $VenvPython -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
