# ==============================================================================
# LEGAL-BRIDGE AI: Launch All Services (Backend + Frontend)
# ==============================================================================
Write-Host "=================================================================" -ForegroundColor Cyan
Write-Host "            LEGAL-BRIDGE AI : SYSTEM LAUNCHER                   " -ForegroundColor Cyan
Write-Host "=================================================================" -ForegroundColor Cyan

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Split-Path -Parent $ScriptDir

# Check Ollama
& (Join-Path $ScriptDir "check-ollama.ps1")

Write-Host "`n>>> Starting Backend in background process..." -ForegroundColor Cyan
Start-Process powershell -ArgumentList "-NoExit", "-ExecutionPolicy Bypass", "-File `"$ScriptDir\start-backend.ps1`""

Start-Sleep -Seconds 2

Write-Host ">>> Starting Frontend in background process..." -ForegroundColor Cyan
Start-Process powershell -ArgumentList "-NoExit", "-ExecutionPolicy Bypass", "-File `"$ScriptDir\start-frontend.ps1`""

Write-Host "`n[READY] Both servers launched!" -ForegroundColor Green
Write-Host "        Frontend: http://localhost:5173" -ForegroundColor White
Write-Host "        Backend:  http://127.0.0.1:8000" -ForegroundColor White
Write-Host "        API Docs: http://127.0.0.1:8000/docs" -ForegroundColor White
