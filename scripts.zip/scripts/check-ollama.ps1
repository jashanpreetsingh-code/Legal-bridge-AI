# ==============================================================================
# LEGAL-BRIDGE AI: Ollama & Gemma Model Status Checker
# ==============================================================================
Write-Host "=== OLLAMA & GEMMA RUNTIME STATUS ===" -ForegroundColor Cyan

# 1. Check CLI
$OllamaCli = Get-Command ollama -ErrorAction SilentlyContinue
if ($OllamaCli) {
    Write-Host "[OK] Ollama CLI found at: $($OllamaCli.Source)" -ForegroundColor Green
    & ollama --version
} else {
    Write-Host "[WARN] Ollama command not found in PATH." -ForegroundColor Yellow
    Write-Host "       Default location is: C:\Users\$env:USERNAME\AppData\Local\Programs\Ollama\ollama.exe"
}

# 2. Check local HTTP endpoint
Write-Host "`n>>> Testing connection to http://localhost:11434..." -ForegroundColor Cyan
try {
    $res = Invoke-RestMethod -Uri "http://localhost:11434/api/tags" -Method Get -TimeoutSec 3 -ErrorAction Stop
    Write-Host "[OK] Ollama server is running and reachable!" -ForegroundColor Green
    Write-Host "Installed models on this machine:" -ForegroundColor White
    if ($res.models.Count -eq 0) {
        Write-Host "  (No models installed yet)" -ForegroundColor Yellow
    } else {
        foreach ($m in $res.models) {
            Write-Host "  - $($m.name) (Size: $([math]::Round($m.size / 1GB, 2)) GB)" -ForegroundColor Cyan
        }
    }

    $HasGemma = $res.models | Where-Object { $_.name -like "*gemma4:26b*" }
    if ($HasGemma) {
        Write-Host "`n[SUCCESS] gemma4:26b is installed and ready to serve!" -ForegroundColor Green
    } else {
        Write-Host "`n[INFO] Primary model 'gemma4:26b' is not yet downloaded." -ForegroundColor Yellow
        Write-Host "       To download when approved, run:  ollama pull gemma4:26b" -ForegroundColor White
        Write-Host "       For rapid local testing on laptop: ollama pull gemma:2b" -ForegroundColor Gray
    }
} catch {
    Write-Host "[OFFLINE] Ollama daemon is currently not running on port 11434." -ForegroundColor Yellow
    Write-Host "          To start Ollama, open a new PowerShell terminal and run:" -ForegroundColor White
    Write-Host "          ollama serve" -ForegroundColor Green
    Write-Host "          (Legal-Bridge AI will automatically use its built-in Demo Simulation Engine until Ollama starts)" -ForegroundColor Cyan
}
